<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class Autoresponse extends Model
{
    protected $table = 'autoresponse';
    protected $guarded = [];
}
