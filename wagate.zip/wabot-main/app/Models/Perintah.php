<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class Perintah extends Model
{
    protected $table = 'perintah';
    protected $guarded = [];
}
