export const hash = Math.floor(Math.random() * 90000) + 10000;
